# How AI assisted

**Scaffolding and boilerplate.** The Vite setup, the `useLocalStorage`
hook, and the repetitive label/input/error JSX in `ProblemForm.jsx` and
`FilterBar.jsx` are the kind of code that's mechanical to write and easy
to get right from a clear spec — the AI produced all of it in one pass and
it needed no changes.

**Structural decisions I'd have made anyway, faster.** Splitting the app
into `StatsBar` / `FilterBar` / `ProblemForm` / `ProblemRow` /
`DsaTracker` instead of one large component, deriving `visible` problems
from `problems` + `filters` on every render instead of storing a separate
filtered list in state, and using a `Set` of lowercase titles for the
duplicate check instead of an O(n) `.some()` scan each keystroke — these
are choices I would have converged on myself, but the AI got there in the
first draft rather than after a refactor.

**Turning vague requirements into a concrete edge-case list.** "Handle
duplicates and bad input" is vague; the prompt in step 4 named specific
behaviors (warn-then-allow for duplicates, confirm-before-delete, reject
malformed URLs) precisely because the AI and I had worked out in
conversation what "handle it" should actually mean for a solo tracker app
— not "block", not "silently ignore", but a low-friction warning.

**Verification loop that caught a real bug in round 4 of the prior
drill's format.** Writing tests immediately after the component and
running them is what surfaced issues before I even started the manual
review — see `CORRECTIONS.md` for what the manual pass caught *on top of*
a fully green test suite.

**Where AI assistance stopped being useful:** the visual design tokens
(exact hex values, type scale, spacing rhythm) needed a second, more
opinionated pass — the first attempt leaned toward a generic dark SaaS
card look before I asked for a monospace/ink-navy direction specific to a
coding log. And the security gap in `isValidUrl` (see corrections) is
exactly the kind of thing a spec-following AI won't flag on its own unless
told to think about it — "valid URL" and "safe URL to render as a link"
are different requirements, and only a human reviewer reading the code
against its actual use (rendered as a clickable `<a href>`) catches that
gap.
