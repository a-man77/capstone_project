# Prompts used during development

App: **Practice Log** — a DSA problem tracker (title, topic, difficulty,
status, optional link), with search/filter and localStorage persistence.
Built with the AI in a single continuous session, prompted in stages.

### 1. Scaffold + visual direction
> "Set up a Vite + React app called dsa-tracker, no CSS framework. This is
> a personal DSA practice log, dark theme, coding-tool feel — not a generic
> SaaS dashboard. Pick a specific dark palette and use a monospace face for
> problem titles/tags since it's code-adjacent, sans-serif for the rest of
> the UI chrome."

### 2. Core data model + CRUD
> "Build the tracker: fields title (required), topic (free text),
> difficulty (easy/medium/hard), status (todo/attempted/solved), optional
> URL. A form at the top adds a problem; a list below shows them. Persist
> everything to localStorage behind a small custom hook, not scattered
> localStorage calls in the component. Clicking a problem's status pill
> should cycle it to the next status."

### 3. Filtering, search, and stats
> "Add a stats bar with counts per status, a filter bar (status +
> difficulty dropdowns, a text search over title and topic), and an empty
> state for both 'no problems yet' and 'no problems match these filters.'
> All client-side, no new dependencies."

### 4. Edge cases + verification
> "Handle these edge cases explicitly: submitting an empty title, a
> malformed URL in the link field, adding a title that already exists
> (warn once, let a second submit add it anyway rather than silently
> blocking), and deleting a problem should require a confirm/cancel step
> instead of deleting immediately. Then write Vitest + Testing Library
> tests covering all of that plus persistence across a remount, and run
> them until they pass."

The manual review pass that followed step 4 (documented in
`CORRECTIONS.md`) was **not** prompted — it came from reading the
AI-generated `constants.js` and `ProblemRow.jsx` by hand after the tests
were already green.
