export const STATUSES = ["todo", "attempted", "solved"];
export const DIFFICULTIES = ["easy", "medium", "hard"];

export const STATUS_LABELS = {
  todo: "To do",
  attempted: "Attempted",
  solved: "Solved",
};

export function isValidUrl(value) {
  if (!value) return true; // optional field
  try {
    const parsed = new URL(value);
    // `new URL()` happily accepts javascript: and data: URIs too — since this
    // value ends up as a rendered <a href>, restrict to http/https so a
    // pasted link can't become a script-executing link.
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}

export function makeId() {
  return `p_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}
