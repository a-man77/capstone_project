import { useState } from "react";
import { STATUS_LABELS } from "./constants";

export default function ProblemRow({ problem, onCycleStatus, onDelete }) {
  const [confirmingDelete, setConfirmingDelete] = useState(false);

  return (
    <li className={`problem-row status-${problem.status}`}>
      <div className="problem-main">
        {problem.url ? (
          <a href={problem.url} target="_blank" rel="noopener noreferrer" className="problem-title">
            {problem.title}
          </a>
        ) : (
          <span className="problem-title">{problem.title}</span>
        )}
        <div className="problem-meta">
          {problem.topic && <span className="tag tag-topic">{problem.topic}</span>}
          <span className={`tag tag-difficulty tag-${problem.difficulty}`}>
            {problem.difficulty}
          </span>
        </div>
      </div>

      <button
        type="button"
        className={`status-pill status-pill-${problem.status}`}
        onClick={() => onCycleStatus(problem.id)}
        aria-label={`Status: ${STATUS_LABELS[problem.status]}. Click to advance.`}
      >
        {STATUS_LABELS[problem.status]}
      </button>

      {confirmingDelete ? (
        <span className="confirm-delete">
          <button
            type="button"
            onClick={() => onDelete(problem.id)}
            className="danger"
            aria-label={`Confirm delete ${problem.title}`}
          >
            Confirm
          </button>
          <button
            type="button"
            onClick={() => setConfirmingDelete(false)}
            aria-label={`Cancel delete ${problem.title}`}
          >
            Cancel
          </button>
        </span>
      ) : (
        <button
          type="button"
          className="icon-button"
          onClick={() => setConfirmingDelete(true)}
          aria-label={`Delete ${problem.title}`}
        >
          Delete
        </button>
      )}
    </li>
  );
}
