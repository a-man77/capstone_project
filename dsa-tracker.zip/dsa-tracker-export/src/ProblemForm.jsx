import { useState } from "react";
import { DIFFICULTIES, isValidUrl, makeId } from "./constants";

const EMPTY = { title: "", topic: "", difficulty: "medium", url: "" };

export default function ProblemForm({ onAdd, existingTitles }) {
  const [values, setValues] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [duplicateWarning, setDuplicateWarning] = useState(false);

  function update(field, value) {
    setValues((v) => ({ ...v, [field]: value }));
  }

  function validate() {
    const next = {};
    if (!values.title.trim()) next.title = "Title is required.";
    if (!isValidUrl(values.url.trim())) next.url = "Enter a full URL, e.g. https://...";
    return next;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    const isDup = existingTitles.has(values.title.trim().toLowerCase());
    if (isDup && !duplicateWarning) {
      setDuplicateWarning(true);
      return;
    }

    onAdd({
      id: makeId(),
      title: values.title.trim(),
      topic: values.topic.trim(),
      difficulty: values.difficulty,
      url: values.url.trim(),
      status: "todo",
      notes: "",
      dateAdded: new Date().toISOString(),
    });
    setValues(EMPTY);
    setErrors({});
    setDuplicateWarning(false);
  }

  return (
    <form className="problem-form" onSubmit={handleSubmit} noValidate>
      <div className="field field-grow">
        <label htmlFor="title">Problem title</label>
        <input
          id="title"
          value={values.title}
          onChange={(e) => {
            update("title", e.target.value);
            setDuplicateWarning(false);
          }}
          aria-invalid={!!errors.title}
          aria-describedby={errors.title ? "title-error" : undefined}
          placeholder="Two Sum"
        />
        {errors.title && (
          <p id="title-error" role="alert" className="field-error">
            {errors.title}
          </p>
        )}
      </div>

      <div className="field">
        <label htmlFor="topic">Topic</label>
        <input
          id="topic"
          value={values.topic}
          onChange={(e) => update("topic", e.target.value)}
          placeholder="Arrays"
        />
      </div>

      <div className="field">
        <label htmlFor="difficulty">Difficulty</label>
        <select
          id="difficulty"
          value={values.difficulty}
          onChange={(e) => update("difficulty", e.target.value)}
        >
          {DIFFICULTIES.map((d) => (
            <option key={d} value={d}>
              {d[0].toUpperCase() + d.slice(1)}
            </option>
          ))}
        </select>
      </div>

      <div className="field field-grow">
        <label htmlFor="url">Link (optional)</label>
        <input
          id="url"
          value={values.url}
          onChange={(e) => update("url", e.target.value)}
          aria-invalid={!!errors.url}
          aria-describedby={errors.url ? "url-error" : undefined}
          placeholder="https://leetcode.com/problems/..."
        />
        {errors.url && (
          <p id="url-error" role="alert" className="field-error">
            {errors.url}
          </p>
        )}
      </div>

      <div className="field field-actions">
        <button type="submit">
          {duplicateWarning ? "Add anyway" : "Add problem"}
        </button>
        {duplicateWarning && (
          <p role="alert" className="field-warning">
            "{values.title.trim()}" is already on your list.
          </p>
        )}
      </div>
    </form>
  );
}
