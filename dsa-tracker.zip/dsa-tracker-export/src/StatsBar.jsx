import { STATUSES, STATUS_LABELS } from "./constants";

export default function StatsBar({ problems }) {
  const counts = STATUSES.reduce((acc, s) => {
    acc[s] = problems.filter((p) => p.status === s).length;
    return acc;
  }, {});
  const total = problems.length;

  return (
    <div className="stats-bar" role="status">
      <div className="stat">
        <span className="stat-value">{total}</span>
        <span className="stat-label">total</span>
      </div>
      {STATUSES.map((s) => (
        <div className="stat" key={s}>
          <span className="stat-value">{counts[s]}</span>
          <span className="stat-label">{STATUS_LABELS[s].toLowerCase()}</span>
        </div>
      ))}
    </div>
  );
}
