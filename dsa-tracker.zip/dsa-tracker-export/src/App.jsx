import DsaTracker from './DsaTracker'
import './index.css'

function App() {
  return <DsaTracker />
}

export default App
