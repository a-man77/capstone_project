import { describe, it, expect, beforeEach } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import DsaTracker from "./DsaTracker";

beforeEach(() => {
  window.localStorage.clear();
});

async function addProblem(user, { title, topic, difficulty, url } = {}) {
  await user.type(screen.getByLabelText(/problem title/i), title);
  if (topic) await user.type(screen.getByLabelText(/topic/i), topic);
  if (difficulty) {
    await user.selectOptions(screen.getByLabelText(/^difficulty$/i), difficulty);
  }
  if (url) await user.type(screen.getByLabelText(/link/i), url);
  await user.click(screen.getByRole("button", { name: /add problem/i }));
}

describe("DsaTracker", () => {
  it("shows an empty state with no problems", () => {
    render(<DsaTracker />);
    expect(screen.getByText(/no problems yet/i)).toBeInTheDocument();
  });

  it("adds a problem and shows it in the list", async () => {
    const user = userEvent.setup();
    render(<DsaTracker />);
    await addProblem(user, { title: "Two Sum", topic: "Arrays" });

    expect(screen.getByText("Two Sum")).toBeInTheDocument();
    expect(screen.getByText("Arrays")).toBeInTheDocument();
  });

  it("rejects an empty title", async () => {
    const user = userEvent.setup();
    render(<DsaTracker />);
    await user.click(screen.getByRole("button", { name: /add problem/i }));

    expect(await screen.findByRole("alert")).toHaveTextContent(/title is required/i);
  });

  it("rejects a malformed URL", async () => {
    const user = userEvent.setup();
    render(<DsaTracker />);
    await addProblem(user, { title: "Two Sum", url: "not-a-url" });

    expect(await screen.findByRole("alert")).toHaveTextContent(/enter a full url/i);
    expect(screen.queryByText("Two Sum")).not.toBeInTheDocument();
  });

  it("rejects a javascript: URL even though it parses as a valid URL", async () => {
    const user = userEvent.setup();
    render(<DsaTracker />);
    await addProblem(user, { title: "Two Sum", url: "javascript:alert(1)" });

    expect(await screen.findByRole("alert")).toHaveTextContent(/enter a full url/i);
    expect(screen.queryByText("Two Sum")).not.toBeInTheDocument();
  });

  it("warns on a duplicate title and requires a second submit to add it anyway", async () => {
    const user = userEvent.setup();
    render(<DsaTracker />);
    await addProblem(user, { title: "Two Sum" });
    await addProblem(user, { title: "Two Sum" });

    expect(screen.getByRole("alert")).toHaveTextContent(/already on your list/i);
    expect(screen.getAllByText("Two Sum")).toHaveLength(1);

    await user.click(screen.getByRole("button", { name: /add anyway/i }));
    expect(screen.getAllByText("Two Sum")).toHaveLength(2);
  });

  it("cycles status from todo to attempted to solved on click", async () => {
    const user = userEvent.setup();
    render(<DsaTracker />);
    await addProblem(user, { title: "Two Sum" });

    const pill = screen.getByRole("button", { name: /status: to do/i });
    await user.click(pill);
    expect(screen.getByRole("button", { name: /status: attempted/i })).toBeInTheDocument();
  });

  it("deletes a problem only after confirming", async () => {
    const user = userEvent.setup();
    render(<DsaTracker />);
    await addProblem(user, { title: "Two Sum" });

    await user.click(screen.getByRole("button", { name: /delete two sum/i }));
    expect(screen.getByText("Two Sum")).toBeInTheDocument(); // still there, awaiting confirm

    await user.click(screen.getByRole("button", { name: /confirm/i }));
    expect(screen.queryByText("Two Sum")).not.toBeInTheDocument();
  });

  it("filters by search text across title and topic", async () => {
    const user = userEvent.setup();
    render(<DsaTracker />);
    await addProblem(user, { title: "Two Sum", topic: "Arrays" });
    await addProblem(user, { title: "Valid Parens", topic: "Stacks" });

    await user.type(screen.getByLabelText(/^search$/i), "stack");
    expect(screen.queryByText("Two Sum")).not.toBeInTheDocument();
    expect(screen.getByText("Valid Parens")).toBeInTheDocument();
  });

  it("persists problems to localStorage across remounts", async () => {
    const user = userEvent.setup();
    const { unmount } = render(<DsaTracker />);
    await addProblem(user, { title: "Two Sum" });
    unmount();

    render(<DsaTracker />);
    expect(screen.getByText("Two Sum")).toBeInTheDocument();
  });
});
