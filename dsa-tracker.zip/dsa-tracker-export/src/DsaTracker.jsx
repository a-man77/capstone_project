import { useMemo, useState } from "react";
import { useLocalStorage } from "./useLocalStorage";
import { STATUSES } from "./constants";
import ProblemForm from "./ProblemForm";
import FilterBar from "./FilterBar";
import StatsBar from "./StatsBar";
import ProblemRow from "./ProblemRow";

const DEFAULT_FILTERS = { search: "", status: "all", difficulty: "all" };

export default function DsaTracker() {
  const [problems, setProblems] = useLocalStorage("dsa-tracker:problems", []);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);

  const existingTitles = useMemo(
    () => new Set(problems.map((p) => p.title.toLowerCase())),
    [problems]
  );

  function addProblem(problem) {
    setProblems((prev) => [problem, ...prev]);
  }

  function cycleStatus(id) {
    setProblems((prev) =>
      prev.map((p) => {
        if (p.id !== id) return p;
        const nextIndex = (STATUSES.indexOf(p.status) + 1) % STATUSES.length;
        return { ...p, status: STATUSES[nextIndex] };
      })
    );
  }

  function deleteProblem(id) {
    setProblems((prev) => prev.filter((p) => p.id !== id));
  }

  const visible = problems.filter((p) => {
    if (filters.status !== "all" && p.status !== filters.status) return false;
    if (filters.difficulty !== "all" && p.difficulty !== filters.difficulty) return false;
    const q = filters.search.trim().toLowerCase();
    if (q && !p.title.toLowerCase().includes(q) && !p.topic.toLowerCase().includes(q)) {
      return false;
    }
    return true;
  });

  return (
    <div className="tracker">
      <header className="tracker-header">
        <h1>Practice Log</h1>
        <p className="tracker-subtitle">Track DSA problems from todo to solved.</p>
      </header>

      <StatsBar problems={problems} />
      <ProblemForm onAdd={addProblem} existingTitles={existingTitles} />
      <FilterBar filters={filters} onChange={setFilters} />

      {problems.length === 0 ? (
        <p className="empty-state">
          No problems yet. Add your first one above to start the log.
        </p>
      ) : visible.length === 0 ? (
        <p className="empty-state">Nothing matches these filters.</p>
      ) : (
        <ul className="problem-list">
          {visible.map((p) => (
            <ProblemRow
              key={p.id}
              problem={p}
              onCycleStatus={cycleStatus}
              onDelete={deleteProblem}
            />
          ))}
        </ul>
      )}
    </div>
  );
}
