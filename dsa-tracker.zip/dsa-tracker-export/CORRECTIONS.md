# Manual corrections after review

The test suite was fully green (9/9) before any of these were made — these
came from reading the AI-generated code by hand, not from a failing test.

### 1. `isValidUrl` accepted unsafe URL schemes (security)

**Before:**
```js
export function isValidUrl(value) {
  if (!value) return true;
  try {
    new URL(value);
    return true;
  } catch {
    return false;
  }
}
```
`new URL()` happily parses `javascript:alert(1)` as a syntactically valid
URL — it has a scheme and no further structural requirement. But this
value is stored and later rendered as `<a href={problem.url}>`, so an
accepted "valid URL" could become a script-executing link. The AI met the
literal spec ("valid URL") without considering the sink the value flows
into.

**After:** restricted acceptance to `http:`/`https:` protocols only, and
added a regression test (`rejects a javascript: URL even though it parses
as a valid URL`) so this doesn't silently regress.

### 2. External link used `rel="noreferrer"` only

`target="_blank"` links should carry both `noopener` and `noreferrer` —
`noreferrer` alone is sufficient in modern browsers but `noopener` makes
the intent explicit and doesn't rely on `noreferrer`'s side effect for
safety. Changed `rel="noreferrer"` to `rel="noopener noreferrer"`.

### 3. Delete confirm/cancel buttons had ambiguous accessible names

The AI's delete-confirmation buttons were just `<button>Confirm</button>`
and `<button>Cancel</button>`. That's fine visually, but a screen reader
user tabbing through a list where more than one row happens to be
mid-delete would hear "Confirm" / "Cancel" with no way to tell which
problem it applies to. Added `aria-label="Confirm delete {title}"` /
`aria-label="Cancel delete {title}"` per row.

### 4. Removed an unused import

`ProblemRow.jsx` imported `STATUSES` from `constants.js` but only used
`STATUS_LABELS` — leftover from an earlier draft of the status-cycling
logic that got moved up into `DsaTracker.jsx`. Removed the dead import
(caught by reading the file, not by a linter — none is configured here).

None of these were required to make the app "work" in the sense the tests
checked — they're the gap between code that passes its own spec and code
that's actually safe/usable, which is what the review pass is for.
