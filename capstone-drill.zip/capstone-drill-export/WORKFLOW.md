# WORKFLOW.md — Vague vs. Precise Prompting on a Settings Form

**Feature:** a settings form (name, email, password, confirm password).
**Round 1** (`round1-vague`): one lazy sentence, output accepted as-is.
**Round 2** (`round2-precise`): a scoped prompt with file references, explicit
validation/a11y/edge-case constraints, and a write-tests-then-run
verification step. Each round ran in its own fresh session/branch off the
same scaffold commit (`b960150`) so round 2 carried no context from round 1.

## The diff, in numbers

| | Round 1 | Round 2 |
|---|---|---|
| `SettingsForm.jsx` | 55 lines | 152 lines |
| Validation | native `required` + one manual `password !== confirmPassword` check | zod schema: length bounds, trimmed name, email format, password strength, cross-field match |
| Labels | none — `placeholder` only | every input has a real `<label htmlFor>` |
| Errors exposed to AT | `alert()` popup for one case only | `role="alert"` + `aria-invalid` + `aria-describedby` per field |
| Submit state | always enabled, no pending state | disabled until valid, "Saving…" during the async call |
| Server-style error case | not handled | handled (`taken@example.com`) |
| Tests | none | 94-line suite, 6 tests, all passing |

`git diff --stat master round1-vague` shows 57 insertions across 2 files.
`git diff --stat master round2-precise` shows 257 insertions across 6 files
— the extra files are the test suite, `setupTests.js`, and `vite.config.js`'s
test block, not padding.

## Correctness

Round 1 "works" for the happy path but silently accepts a whitespace-only
name and has no password strength rule. Round 2's zod schema encodes every
one of those as an explicit, testable rule.

## Accessibility

Round 1 uses `placeholder` as the only field identifier — it disappears on
input and isn't a substitute for a `<label>`. Its only error path is a
blocking `alert()`, unconnected to any field. Round 2 associates every
input with a label and threads error state through
`aria-invalid`/`aria-describedby`/`role="alert"`.

## Edge cases

Round 1 catches exactly one edge case (password mismatch, via `alert`).
Round 2's prompt named the edge cases up front (empty submit, mismatch,
whitespace name, taken email) and the tests hold the implementation to them.

## Review effort

Round 1 took under a minute to get output, but reviewing it meant deciding
*myself*, after the fact, which missing behaviors mattered enough to send
back for a rewrite — real time the round-1 clock doesn't show. Round 2 took
longer to prompt, and its first draft of *tests* had a real bug: three of
six failed because `findByRole("alert", { name: /.../ })` tries to match an
accessible *name*, and `role="alert"` elements don't compute one from text
content per the ARIA accname spec — the matcher was wrong, not the
component. I caught it because the verification step actually ran the
suite instead of trusting "tests were written." The fix
(`toHaveTextContent` instead of a `name` filter) took two minutes. Counting
prompt-writing + review + that fix, round 2's total time landed close to
round 1's — round 1 just hadn't paid its second-pass cost yet. Round 2
front-loaded the cost into the prompt instead of into review.
