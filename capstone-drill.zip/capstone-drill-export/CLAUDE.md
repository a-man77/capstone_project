# Project rules

Learned from the round1-vague vs round2-precise settings-form drill
(see WORKFLOW.md). These are testable, not vibes — each one can fail
a review.

1. **Forms use `react-hook-form` + `zod` via `@hookform/resolvers`, never
   uncontrolled inputs with manual `.value` reads.** Round 1's uncontrolled
   version had no single source of truth for validity and made the submit
   button impossible to correctly disable/enable.

2. **Every form input must have a real `<label htmlFor>` bound to its `id`
   — `placeholder` is never an acceptable substitute.** Round 1 relied on
   placeholder text alone; it fails `getByLabelText` in tests and fails for
   screen reader users the moment the field has a value.

3. **Every validation/server error must be a `role="alert"` element wired to
   its field with `aria-invalid` + `aria-describedby` — never `alert()` or
   an untied error string.** When asserting on an alert's content in tests,
   use `getByRole("alert")` + `toHaveTextContent(...)`, not
   `getByRole("alert", { name: ... })` — `role="alert"` does not compute an
   accessible name from its text content per the ARIA accname spec, so the
   `name` matcher silently never matches.

4. **A feature isn't done until its tests are written *and run* in the same
   pass.** "Write it, then write tests and run them" surfaced a real bug
   (rule 3) that a written-but-unrun test suite would have hidden.
